package com.cisco.app;

import java.util.ArrayList;
import java.util.HashSet;

public class GraphNode implements GNode, Cloneable {
	
	private String name;
	private ArrayList<GraphNode> children;
	
	public GraphNode(String name) {
		
		this.name = name;
		children = new ArrayList<GraphNode>();
	}
	
	public String getName() {
		
		return this.name;
	}
	
	public void addChild(GraphNode child) {
		
		if (child == null) {
			return;
		}
		children.add(child);
	}
	
    public GraphNode[] getChildren() {
    	
    	return ((GraphNode[]) children.toArray(new GraphNode[children.size()]));
    }
    
    /*
     * Utility method to find a node from a starting point.
     */
    public GraphNode findNode(GraphNode node, String str) {
    	
    	if (node == null) {
    		return null;
    	}
    	
    	if (node.getName() == str) {
			return node;
		}
    	
	    for (GraphNode child: node.getChildren()) {
	    	GraphNode temp = findNode(child, str);
	    	if (temp != null) {
	    		return temp;
	    	}
    	}

    	return null;
    }
    
    /*
     * Method to build the Graph
     */
    public void buildGraph(String[][] graph) {
    	
    	for (int i=0; i<graph.length; i++) {
    		GraphNode node = findNode(this, graph[i][0]);
    		if (node == null) {
    			/*
    			 * Creating an orphan node here but this will be unreachable from 'root'.
    			 */
				node = new GraphNode(graph[i][0]);
			}
    		for (int j=1; j<graph[i].length; j++) {
    			GraphNode child = findNode(this, graph[i][j]);
    			if (child != null) {
    				/* 
    				 * Detect a loop here before adding an existing node as 'child'.
    				 * If 'node' can be reached starting from 'child', loop is found!
    				 */
    				if (findNode(child, node.getName()) != null) {
    		    		System.out.println("Found a loop, skipping child " + child.getName() + " for node " + node.getName());
    		    	} else {
    		    		node.addChild(child);
    		    	}
    			} else {
    				node.addChild(new GraphNode(graph[i][j]));
    			}
        	}
        }
    }    	
    
    /*
     * Helped method for recursively displaying the graph
     */
    public void display(GraphNode node, String str) {
    	
    	System.out.println(str + node.getName());

    	for (GraphNode child : node.getChildren()) {
        	display(child, str + "  ");
    	}
    }
    
    /*
     * Method to display the Graph with nodes and their children
     */
    public void displayGraph() {
    	
    	display(this, "");
    }
    
    /*
     * Helper method to walk the graph
     */
    public void walkGraph(GraphNode node, ArrayList<GraphNode> gList, HashSet<String> set) {
    	
    	String name = node.getName();
    	if (set.contains(name)) {
    		return;
    	}
    	set.add(name);
    	gList.add(node);

    	for (GraphNode child : node.getChildren()) {
        	walkGraph(child, gList, set);
    	}        	
    }
    
    /*
     * Method to walk the Graph and return a list of all unique nodes (no duplicates, no skipped nodes)
     */
    public ArrayList<GraphNode> walkGraph() {
    	
    	ArrayList<GraphNode> gList = new ArrayList<GraphNode>();
    	HashSet<String> set = new HashSet<String>();
    	walkGraph(this, gList, set);
    	return gList;
    }

    /*
     * Helper method to perform a deep copy of an ArrayList of GraphNode elements.
     */
    public ArrayList<GraphNode> deepCopy(ArrayList<GraphNode> gList) throws CloneNotSupportedException {
    	
    	ArrayList<GraphNode> gListClone = new ArrayList<GraphNode>(); 
        
        for(GraphNode node: gList) {
        	gListClone.add((GraphNode)node.clone());
        }
        return gListClone;
    }
    
    
    @Override
    protected GraphNode clone() throws CloneNotSupportedException {
    	
    	GraphNode clone = null;
        try
        {
            clone = (GraphNode)super.clone(); 
        } 
        catch (CloneNotSupportedException e) 
        {
            throw new RuntimeException(e);
        }
        return clone;
    }
    
    
    /*
     * Helper method to recursively create a list of paths
     */
    public void pathsGraph(GraphNode node, ArrayList<ArrayList<GraphNode>> aList, ArrayList<GraphNode> gList) {
    	
    	GraphNode[] childNodes = node.getChildren();
    	if (childNodes.length == 0) {
    		try { 
    			ArrayList<GraphNode> tList = deepCopy(gList); 
    			tList.add(node);
        		aList.add(tList);
    		} catch (CloneNotSupportedException e) {
    	        // this shouldn't happen, since GraphNode is Clone-able
    	        throw new InternalError(e);
    	    }
    		return;
    	}

    	gList.add(node);
    	for (GraphNode child : childNodes) {
        	pathsGraph(child, aList, gList);
   
    	}
    	gList.remove(node);
    }
    
    /*
     * Method to list all the paths from 'root'. 
     * Returns an ArrayList of ArrayList of GraphNode elements.
     */
    public ArrayList<ArrayList<GraphNode>> paths() {
    	
    	ArrayList<ArrayList<GraphNode>> aList = new ArrayList<ArrayList<GraphNode>>();
    	ArrayList<GraphNode> gList = new ArrayList<GraphNode>();
    	pathsGraph(this, aList, gList);
    	
    	return aList;
    }
    
    public static void main(String[] args) {
    	
    	/*
    	 * Assumptions/restrictions
    	 * - Graph input will be provided using a 2D array
    	 * - Graph will have one root node and zero or more children.
    	 * - Each row will represent a parent and its children, with
    	 *   the parent being the first element in the row.
    	 * - The first element of first row will be the root.
    	 */
   
    	// Test case 1
		System.out.println("\nTest case 1");
		String[][] graph = {
				{"A", "B", "C", "D"},
				{"B", "E", "F"},
				{"C", "G", "H", "I"},
				{"D", "J"},
		};
    	GraphNode root = new GraphNode(graph[0][0]);
    	root.buildGraph(graph);
    	root.displayGraph();
    	
    	ArrayList<GraphNode> gList = root.walkGraph();
    	System.out.print("Output of walk for root " + root.getName() + ": [ ");
    	for (GraphNode node: gList) {
    		System.out.print(node.getName() + " ");
    	}
		System.out.println("]");
    	
    	// Test case 1.1
		System.out.println("\nTest case 1.1");
    	System.out.print("Paths(" + root.getName() + "):  (" );
    	ArrayList<ArrayList<GraphNode>> aList = root.paths();
    	for (ArrayList<GraphNode> gElem: aList) {
    		System.out.print("( ");
    		for (GraphNode gNode: gElem) {
        		System.out.print(gNode.getName() + " ");
    		}
    		System.out.print(")");

    	}
    	System.out.println(")");
    	
    	// Test case 1.2
		System.out.println("\nTest case 1.2");
    	GraphNode temp = root.findNode(root, "C");
    	System.out.print("Paths(" + temp.getName() + "):  (" );
    	aList = temp.paths();
    	for (ArrayList<GraphNode> gElem: aList) {
    		System.out.print("( ");
    		for (GraphNode gNode: gElem) {
        		System.out.print(gNode.getName() + " ");
    		}
    		System.out.print(")");

    	}
    	System.out.println(")");
    	
    	
    	// Test case 2
		System.out.println("\nTest case 2");

		String[][] xgraph = {
				{"X"},
		};
    	root = new GraphNode(xgraph[0][0]);
    	root.buildGraph(xgraph);
    	root.displayGraph();
    	
    	gList = root.walkGraph();
    	System.out.print("Output of walk for root " + root.getName() + ": [ ");
    	for (GraphNode node: gList) {
    		System.out.print(node.getName() + " ");
    	}
		System.out.println("]");
    	
    	// Test case 2.1
		System.out.println("\nTest case 2.1");
    	System.out.print("Paths(" + root.getName() + "):  (" );
    	aList = root.paths();
    	for (ArrayList<GraphNode> gElem: aList) {
    		System.out.print("( ");
    		for (GraphNode gNode: gElem) {
        		System.out.print(gNode.getName() + " ");
    		}
    		System.out.print(")");

    	}
    	System.out.println(")");
    	
    	
    	// Test case 3
		System.out.println("\nTest case 3");

    	String[][] ygraph = {
    			{"A", "B", "C", "D"},
    			{"B", "E", "F", "G"},
    			{"C", "F", "G", "H", "I"},
    			{"G", "D"},   
    			{"D", "B", "J"},   // Creating a loop here, D->B->G->D !
    	};
	 			  			 
    	root = new GraphNode(ygraph[0][0]);
    	root.buildGraph(ygraph);
    	root.displayGraph();

    	gList = root.walkGraph();
		System.out.print("Output of walk for root " + root.getName() + ": [ ");
    	for (GraphNode node: gList) {
    		System.out.print(node.getName() + " ");
    	}
		System.out.println("]");


    	// Test case 3.1
    	System.out.println("\nTest case 3.1");
    	System.out.print("Paths(" + root.getName() + "):  (" );
    	aList = root.paths();
    	for (ArrayList<GraphNode> gElem: aList) {
    		System.out.print("( ");
    		for (GraphNode gNode: gElem) {
    			System.out.print(gNode.getName() + " ");
    		}
    		System.out.print(")");

    	}
    	System.out.println(")");
    	
    	// Test case 3.2
		System.out.println("\nTest case 3.2");
    	temp = root.findNode(root, "C");
    	System.out.print("Paths(" + temp.getName() + "):  (" );
    	aList = temp.paths();
    	for (ArrayList<GraphNode> gElem: aList) {
    		System.out.print("( ");
    		for (GraphNode gNode: gElem) {
        		System.out.print(gNode.getName() + " ");
    		}
    		System.out.print(")");

    	}
    	System.out.println(")");
    }
}

