Contents of tar.gz:
===================
drwxr-xr-x   7 speechu  staff   224 Feb 17 14:19 .
drwxr-xr-x+ 92 speechu  staff  2944 Feb 17 14:18 ..
-rw-r--r--   1 speechu  staff  1555 Feb 17 14:18 README.txt
drwxr-xr-x   5 speechu  staff   160 Feb 17 14:20 graph-app
-rw-r--r--   1 speechu  staff   350 Feb 17 13:19 input.txt
-rw-r--r--   1 speechu  staff  3680 Feb 17 13:18 lorem.txt
-rw-r--r--@  1 speechu  staff  1185 Feb 17 13:53 wordcount.py


Environment used:
=================
The code has been tested to work in the following environment.

Python 3.9.1
java 13.0.1
Apache Maven 3.6.3


Java code instructions:
=======================
The code is packaged into the folder 'graph-app'.

There are two source files, the interface file GNode.java and class file 
GraphNode.java.

The following assumptions about the graph have been made.

* Assumptions/restrictions
 - Graph input will be provided using a 2D array
 - Graph will have one root node and zero or more children.
 - Each row will represent a parent and its children, with
   the parent being the first element in the row.
 - The first element of first row will be the root.
 
3 test cases are included, the last one with a loop. The code is able to 
detect and remove the loop.


To compile and build, use mvn as follows.
'cd graph-app'
'mvn package'

To run the code, use the following command.
'java -cp target/graph-app-1.0-SNAPSHOT.jar com.cisco.app.GraphNode'


For each test case, the output shows a graph display (like in Word doc),
the output of walkGraph(), and the output of paths().



Python code instructions:
=========================
Python was used for the 3rd exercise.

The code can be run as follows.

$ python wordcount.py -i input.txt -o output.txt 
Processing input file: input.txt
Finished writing to output file: output.txt


The input can be any text file and the output will appear like the following.

15 .
3 be
2 this
2 is
2 text
2 file
2 to
2 will
1 a
1 sample
1 with
1 random
1 pieces

Two sample files 'input.txt' and 'lorem.txt' have been included for  
testing purposes.

=============================================================================
