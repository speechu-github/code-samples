#!/usr/local/bin/python3
#
#  Usage: python3 wordcount.py -i <inputfile> -o <outputfile>
#
#  Examples:
#        python3 wordcount.py -i input.txt -o output.txt
#

import sys
import argparse
from collections import Counter

# Function to count words 
def wordCount(inputfile, outputfile):
    print ('Processing input file: ' + inputfile)
    outfile = open(outputfile, 'a')

    counter = Counter() 
    # Open inputfile as file 'infile'
    with open(inputfile, 'r') as infile:
        while line := infile.readline():
            words = line.split()
            counter += Counter(words)

    sortedList = counter.most_common()
    for elem in sortedList: 
        outfile.write(str(elem[1]) + " " + elem[0] + "\n")
    print ('Finished writing to output file: ' + outputfile)
    outfile.close()


# Parse arguments
parser = argparse.ArgumentParser()
parser.add_argument('-i', '--inputfile', help='name of input file')
parser.add_argument('-o', '--outputfile', help='name of output file')
args = parser.parse_args()

if args.inputfile == None or args.outputfile == None:
  parser.print_help()
  sys.exit()

# Call the wordCount function
wordCount(args.inputfile, args.outputfile)
